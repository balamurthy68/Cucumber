package Cucumber.CGI_July2021Version2;

import java.util.regex.*;


public class regExpExample  {
    public static void main(String[] args) {
        /*
    	System.setProperty ("webdriver.chrome.driver","D://seleniu//chromedriver.exe" );
		
    	WebDriver driver = new ChromeDriver();
        // And now use this to visit Google
        driver.get("file:///D:/Bala%20laptop/RPS/Examples/sample.html");
        
        String timeString = driver.findElement(By.id("txt")).getText();     
        
        System.out.println(timeString); 
        
        Pattern p = Pattern.compile("[0-9]{2}:[0-9]{2}:[0-9]{2}");
        Matcher m = p.matcher(timeString);
    */    
    	//String exampleString = "aaaaaabpotterabcd";
    	//Pattern p = Pattern.compile(".*potter.*");
        //String begins with H
    //	Pattern p = Pattern.compile("^H.*");
    	
    	//Pattern p = Pattern.compile("[0-9]{2}:[0-9]{2}:[0-9]{2}");
        ////*[@id="ct"]
    	//hh:mm:ss
    	//Aug 22, 2019
    	
    	//String exampleString = "04:30:45";
    	
    	String exampleString = "Apr 14, 2021";
        Pattern p = Pattern.compile("[A-Z,a-z]{3} [0-9]{2}, [0-9]{4}");
    	//Pattern p = Pattern.compile("^(19|20)\\d\\d[- /.](0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])$"); 
    	//String exampleString = "2021-02-22";
    
    	boolean ans = false;
		try {
			ans = patternMatch(exampleString,p);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}    
        System.out.println(ans);       
    }
    
    //Patternmatcher    
        public static boolean patternMatch(String exampleString,Pattern p)
        {
        
        	Matcher m = p.matcher(exampleString);
            
            boolean b = m.matches();
            
            return b;       
            
        }
        //Close the browser
      //  driver.quit();
    }
