package Cucumber.CGI_July2021Version2;


	import java.io.File;


import org.openqa.selenium.OutputType;

	import org.openqa.selenium.TakesScreenshot;

	import org.openqa.selenium.WebDriver;

	import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.Test;

	
//	    @Test
	    public class TakeScreenshot {
	    	static WebDriver driver ;
	    public static void main(String[] args) throws Exception{

			
	    	System.setProperty("webdriver.gecko.driver","d:\\seleniu\\geckodriver.exe");
	    	driver = new FirefoxDriver();

	        //goto url

	        driver.get("http://www.google.com");

	        //Call take screenshot function

	        takeSnapShot(driver, "d://seleniu/test.png");     

	    }

	    /**

	     * This function will take screenshot

	     * @param webdriver

	     * @param fileWithPath

	     * @throws Exception

	     */

	    public static void takeSnapShot(WebDriver webdriver,String fileWithPath) throws Exception{

	        //Convert web driver object to TakeScreenshot

	        TakesScreenshot scrShot =((TakesScreenshot)webdriver);

	        //Call getScreenshotAs method to create image file

	                File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);

	            //Move image file to new destination

	                File DestFile=new File(fileWithPath);

	                //Copy file at destination
	                FileHandler.copy(SrcFile, DestFile);
	    }
	}
