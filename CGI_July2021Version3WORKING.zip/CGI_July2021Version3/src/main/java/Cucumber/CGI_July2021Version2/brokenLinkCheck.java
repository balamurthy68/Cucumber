package Cucumber.CGI_July2021Version2;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class brokenLinkCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		openBaseURL("D:\\radiobtnExample.html");
		
	}	
		
		public static void openBaseURL(String url)
		{
		
        WebDriver driver;
        driver = new FirefoxDriver();
        System.setProperty("webdriver.gecko.driver", "d:\\geckodriver.exe");
        driver.get(url);
        
        WebElement linkSignIn;
                
       List <WebElement> allLinks = driver.findElements(By.tagName("a"));
       System.out.println("There are " + allLinks.size() + " links in this page");
       
       for (WebElement l: allLinks) {
    	   // System.out.println(l.getText() + " ***** " + l.getAttribute("href"));
    	    verifyLink(l.getAttribute("href"));
       }
	}
       
	
	
	
	//The below function verifyLink(String urlLink) verifies any broken links and return the server status. 

public static void verifyLink(String urlLink) {
     //Sometimes we may face exception "java.net.MalformedURLException". Keep the code in try catch block to continue the broken link analysis
     try {
			//Use URL Class - Create object of the URL Class and pass the urlLink as parameter 
			URL link = new URL(urlLink);
			// Create a connection using URL object (i.e., link)
			HttpURLConnection httpConn =(HttpURLConnection)link.openConnection();
			//Set the timeout for 2 seconds
			httpConn.setConnectTimeout(2000);
			//connect using connect method
			httpConn.connect();
			
			//use getResponseCode() to get the response code.
			System.out.println( urlLink+" - "+httpConn.getResponseMessage());
								
			}
			//getResponseCode method returns = IOException - if an error occurred connecting to the server. 
		catch (Exception e) {
			//e.printStackTrace();
			System.out.print("Broken:" );
			System.out.println(e.getMessage());
			
		}
 } 


}

