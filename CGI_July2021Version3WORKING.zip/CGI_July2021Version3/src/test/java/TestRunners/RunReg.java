package TestRunners;

import java.io.*;

import org.junit.AfterClass;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;


@RunWith(Cucumber.class)
@CucumberOptions(
		//features = "src/test/java/Features/LoginHK.feature"
		features = "src/test/java/Features/Registration.feature"
		,glue={"StepDefs"},
		plugin = {"pretty","html:target/html","json:target/json/cucumber.json",
				"junit:target/xmlreports/report.xml"},
				monochrome=true,
				strict=true)
public class RunReg {
}