package StepDefs;

import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Cucumber.CGI_July2021Version2.TakeScreenshot;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class LoginStepDef {
	
	static WebDriver driver;
	@Given("^herokuapps login page is opened$")
	public void herokuapps_login_page_is_opened() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "d:\\chromedriver.exe");
		
		driver=new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS);
		
		driver.get("https://the-internet.herokuapp.com/login");
		
	   System.out.println("**login page opened"); 
	}

	
	@When("^the right username \"([^\"]*)\" is input$")
	public void the_right_username_is_input(String arg1) throws Throwable {

	    // Write code here that turns the phrase above into concrete actions
		System.out.println("**username is right"+ " " + arg1);
		try {
			driver.findElement(By.id("username")).sendKeys(arg1);
		}
		catch (NoSuchElementException e)
		{
			System.out.println("No username");
			//Take a screenshot here
			TakeScreenshot ts=new TakeScreenshot();
			ts.takeSnapShot(driver, "d:\\usernameboxnotfound.png");
		}

		
		
	}

@And("^the right password \"([^\"]*)\" is input$")
	public void the_right_password_is_input(String pwd) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("**password is right -- "+ pwd);
		try {
			driver.findElement(By.id("password")).sendKeys(pwd);
		}
		catch (NoSuchElementException e)
		{
			System.out.println("No password");
		}

		
	}


	@When("^the wrong \"([^\"]*)\" and \"([^\"]*)\" is input$")
	public void the_wrong_and_is_input(String uname, String pwd) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 //First username
		try {
			driver.findElement(By.id("username")).sendKeys(uname);
		}
		catch (NoSuchElementException e)
		{
			System.out.println("No username");
			//Take a screenshot here
		}
		// Then the password
		try {
			driver.findElement(By.id("password")).sendKeys(pwd);
		}
		catch (NoSuchElementException e)
		{
			System.out.println("No password");
		}

		
		
		
	}

	@Then("^user should not be able to login$")
	public void user_should_not_be_able_to_login() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions

		//#flash
		
		
		String msg=driver.findElement(By.cssSelector("#flash")).getText();
		if (msg.contains("invalid"))
		{
			System.out.println("Invalid user not logged in as expected");
		}
		
		
	}

	
	@When("^submit button is clicked$")
	public void submit_button_is_clicked() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.cssSelector("#login > button > i")).click();

		System.out.println("**submit button clicked");
	}

	@Then("^user should login successfully$")
	public void user_should_login_successfully() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		//#flash
		
		String successmsg=driver.findElement(By.cssSelector("#flash")).getText();
		if (successmsg.contains(" You logged into a secure area!"))
		{
			System.out.println("Valid user logged in successfully as expected");
		}
		
		System.out.println("**Login Success!");
		//Assert.assertEquals(true,false);
	}

	@Then("^should see the logout button$")
	public void should_see_the_logout_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 
		//User should see the logout button
		//#content > div > a > i
		try {
			driver.findElement(By.cssSelector("#content > div > a > i"));
		}
		catch (NoSuchElementException e)
		{
			System.out.println("Unable to login with the right username and password");
			//call the screenshot method
		
		}
	}


}
