package StepDefs;

import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Hooks {

	@Before("@Sanity")
	public void setup()
	{
	
		System.out.println("I am BEFORE Sanity");
		
	}
	
	@After("@Sanity")
	public void teardown()
	{
	
		System.out.println("I am AFTER Sanity");
		
	}
	
	
}
