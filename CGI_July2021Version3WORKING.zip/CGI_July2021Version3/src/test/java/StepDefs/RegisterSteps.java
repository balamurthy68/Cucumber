package StepDefs;

import java.util.List;
import java.util.Map;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class RegisterSteps {
	@Given("^User loads abc website$")
	public void user_loads_abc_website() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
		System.out.println("Website loaded");
	}

	@And("^clicks on Register link$")
	public void clicks_on_Register_link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   System.out.println("Clicked on Register link");
	}

	@And("^fills the data for Registration$")
	public void fills_the_data_for_Registration(DataTable arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
	    // E,K,V must be a scalar (String, Integer, Date, enum etc)
		List<Map<String,String>> data = arg1.asMaps(String.class,String.class);
		
		int numRecs = data.size();
		for (int i=0 ; i <numRecs;i++)
		{
			System.out.println("Username" + data.get(i).get("Username"));
		}
		//driver.findElement(By.id("log")).sendKeys(data.get(0).get("Username")); 
	    //driver.findElement(By.id("pwd")).sendKeys(data.get(0).get("Password"));
	    //driver.findElement(By.id("login")).click();

		
	}

	@And("^clicks on Register button$")
	public void clicks_on_Register_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^Success msg should be displayed$")
	public void success_msg_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^check if Register link is present$")
	public void check_if_Register_link_is_present() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
		
	}


}
