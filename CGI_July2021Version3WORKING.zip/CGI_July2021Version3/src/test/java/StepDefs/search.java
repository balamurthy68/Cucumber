package StepDefs;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

//import org.apache.log4j.LogManager;
//import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


import Cucumber.CGI_July2021Version2.brokenLinkCheck;
import Cucumber.CGI_July2021Version2.regExpExample;
import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class search {
	
	static WebDriver driver;
	
	//private static  Logger LOGGER=LogManager.getLogger(search.class);
	
	@Given("^the homepage is opened$")
	public void the_homepage_is_opened() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions

		System.setProperty("webdriver.chrome.driver", "d:\\chromedriver.exe");
		
		driver=new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS);
		
		driver.get("https://advantageonlineshopping.com/#/");
		driver.manage().window().maximize();

		//---------------------------
CommonStep.scenario.write("I am insideSetup");
		
CommonStep.getTest().debug("user open the browser and enter url");
				  
	    // Write code here that turns the phrase above into concrete actions
	//	LOGGER.info("user open the browser and enter url");
		CommonStep.getTest().debug("title");
		
		final byte[] screenshot =  ((TakesScreenshot) SeleniumUtil.getDriver()).getScreenshotAs(OutputType.BYTES);
		CommonStep.scenario.embed(screenshot, "image/png");
	
		CommonStep.scenario.write("taking screen shot");
		
		//String imagePath=SeleniumUtil.takeScreenShotReturnPath();
		//CommonStep.getTest().addScreenCaptureFromPath(imagePath, "open browser");

		//-----------------------
		
		
		
	}

	@And("^user clicks on search button$")
	public void user_clicks_on_search_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   driver.findElement(By.id("menuSearch")).click();
		
	}

	@When("^user inputs search text$")
	public void inputs_search_text(DataTable mydatatable) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
	    // E,K,V must be a scalar (String, Integer, Date, enum etc)
		List<List<String>> data = mydatatable.raw();

		//This is to get the first data of the set (First Row + First Column)
		WebElement searchBox = driver.findElement(By.id("autoComplete"));
		
		
		List<List<String>> rows = mydatatable.asLists(String.class);
	    
	    for (List<String> columns : rows) {
	    	searchBox.clear();
			
	        searchBox.sendKeys(columns.get(0));
			System.out.println("Searching for " + columns.get(0));
			Thread.sleep(1000);
	    
	    }	
		
			
		
		//
	
	}

	@Then("^user should be able to see the output$")
	public void user_should_be_able_to_see_the_output() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^check for broken links$")
	public void check_for_broken_links() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		brokenLinkCheck bl = new brokenLinkCheck();
		bl.openBaseURL("https://advantageonlineshopping.com/#/");
				
	
	}

	@Given("^timeanddate website is opened$")
	public void timeanddate_website_is_opened() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
		System.setProperty("webdriver.chrome.driver", "d:\\chromedriver.exe");
		
		driver=new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS);
		
		driver.get("https://www.timeanddate.com/");
		driver.manage().window().maximize();
		
	
	}

	@Then("^check for time display hh:mm$")
	public void check_for_time_display_hh_mm() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String currenttime = driver.findElement(By.id("clk_hm")).getText();
		System.out.println(currenttime);
		regExpExample re=new regExpExample();
		Pattern p=Pattern.compile("[0-9]{2}:[0-9]{2}");
		boolean matched = re.patternMatch(currenttime,p);
		System.out.println("The hour minute display is "+ matched);
		    
	
	
	}

}
